﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Oscillator : MonoBehaviour {

	double v;
	double x;
	double m = 1;
	double k = 1;

	// Use this for initialization
	void Start () {
		x = transform.position.x;
		v = 0.0;
	}
	
	// Update is called once per frame
	void Update () {
		double h = Time.deltaTime;
		v = v - k / m * x * h;
		x = x + v * h;
		transform.position = new Vector3 ((float)x, 
			transform.position.y, transform.position.z);
	}
}
