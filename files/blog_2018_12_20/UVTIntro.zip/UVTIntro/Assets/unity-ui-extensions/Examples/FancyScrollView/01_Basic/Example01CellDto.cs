﻿namespace UnityEngine.UI.Extensions.Examples
{
    public class Example01CellDto
    {
        public string Message;
    }
}
