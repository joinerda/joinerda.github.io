﻿namespace UnityEngine.UI.Extensions.Examples
{
    public class Example02CellDto
    {
        public string Message;
    }
}
