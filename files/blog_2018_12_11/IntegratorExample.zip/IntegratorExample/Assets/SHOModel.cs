﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SHOModel : MonoBehaviour {

	public GameObject objectToMove;
	SHOIntegrator theIntegrator;
	double t = 0.0;
	double h = 0.01;

	// Use this for initialization
	void Start () {
		theIntegrator = new SHOIntegrator ();
		theIntegrator.SetIC (1, 0);
		
	}

	void FixedUpdate() {
		t = theIntegrator.RK4Step (theIntegrator.x, t, h);
	}
	
	// Update is called once per frame
	void Update () {
		Vector3 pos = objectToMove.transform.position;
		pos.x = (float)theIntegrator.x [0];
		objectToMove.transform.position = pos;
	}
}
