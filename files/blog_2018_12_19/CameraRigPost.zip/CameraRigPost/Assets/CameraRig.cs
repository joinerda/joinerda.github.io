﻿//#define ROLL_ENABLED
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraRig : MonoBehaviour {

	CharacterController cc = null;
	float speed = 20.0f;
	float lookspeed =80.0f;
	float rollspeed =40.0f;

	// Use this for initialization
	void Start () {
		cc = GetComponent<CharacterController> ();
	}
	
	// Update is called once per frame
	void Update () {
		float forward = Input.GetAxis ("Vertical");
		float strafe = Input.GetAxis ("Horizontal");
		float jump = Input.GetAxis ("Jump");
		float lookside = Input.GetAxis ("Mouse X");
		float lookup = -Input.GetAxis ("Mouse Y");
		float roll = Input.GetAxis ("Roll");

		cc.Move (
			speed * Time.deltaTime * (
				forward * transform.forward
				+
				strafe * transform.right
				+
				jump * transform.up
			)
		);

		if (Input.GetMouseButton (1)) {
			Vector3 rotAxis = (lookside * transform.up + lookup * transform.right);
			float rotValue = rotAxis.magnitude;
			transform.Rotate (rotAxis.normalized, rotValue * lookspeed * Time.deltaTime, Space.World);
		}
		#if ROLL_ENABLED
		transform.Rotate (transform.forward, rollspeed * roll * Time.deltaTime, Space.World);
		#endif
	}
}
