﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Body : MonoBehaviour {

	public GameObject left = null;
	public GameObject right = null;

	float k=1;
	public float m=1;
	float l=2;
	float v=0;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (left != null && right != null) {
			float my_x = transform.position.x;
			float left_x = left.GetComponent<Body> ().transform.position.x;
			float right_x = right.GetComponent<Body> ().transform.position.x;
			float force_left = -k * (my_x - (left_x + l));
			float force_right = -k * (my_x - (right_x - l));

			// a = F/m
			v += (force_left + force_right) / m * Time.deltaTime;

			// can't change transform.position.x directly in Unity so
			//    do this in steps.
			Vector3 newPosition = Vector3.zero;
			newPosition.x = transform.position.x + v * Time.deltaTime;
			transform.position = newPosition;

			if (v < 0) {
				GetComponent<Renderer> ().material.color = Color.Lerp (Color.green, Color.red, -v+0.5f);
			} else {
				GetComponent<Renderer> ().material.color = Color.Lerp (Color.green, Color.blue, v+0.5f);
			}
		}
		
	}
}
